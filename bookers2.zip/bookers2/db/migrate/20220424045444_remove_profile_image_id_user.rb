class RemoveProfileImageIdUser < ActiveRecord::Migration[5.2]
  def change
  end
end
