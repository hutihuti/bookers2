class BooksController < ApplicationController

  before_action :guard_book, only: [:edit, :update, :destroy]

  def new
    @book = Book.new
  end

  def create
    @book = Book.new(book_params)
    @book.user_id = current_user.id
    if @book.save
    flash[:success] = "successfully：投稿しました"
    redirect_to book_path(@book.id)
    else
    @books = Book.all
    render :index
    end
  end

  def index
    @books = Book.all
    @book = Book.new
  end

  def show
    @book = Book.new
    @book1 = Book.find(params[:id])
    @user = @book1.user
  end

  def edit
    @book = Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
    flash[:success] = "successfully：投稿を編集しました"
    redirect_to book_path(@book.id)
    else
    render :edit
    end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
     flash[:success] = "投稿を削除しました"
    redirect_to books_path
  end

  private
  def book_params
    params.require(:book).permit(:title, :body)
  end

  def guard_book
   @book = Book.find(params[:id])
   @user = @book.user
   unless @user == current_user
   flash[:warning] = "投稿ユーザー以外は編集、削除はできません"
   redirect_to(books_path)
   end
  end

end
