# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '28ac65967fed031c18fb44577251eddb61fa62aef81e4764e34f4817ad1f0531a1d554d1f3b146960f3ffc49864eac62e7d942948bc0cf6a602cf3e27335612f'